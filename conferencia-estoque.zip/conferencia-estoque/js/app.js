// ---------------- Estado ----------------
let itensNota = [];
let lancamentosFisico = [];
let unidadeNotaAtual = "kg";
let unidadeFisicoAtual = "kg";
let tipoLancamentoAtual = "palete";
let filtroStatusAtual = "TODOS";

const STATUS_CONFIG = {
  OK: { label: "OK", cor: "#2F9E4C", bg: "#EAF7EE" },
  FALTA: { label: "Falta", cor: "#D6473C", bg: "#FBEAE8" },
  SOBRA: { label: "Sobra", cor: "#C97A1F", bg: "#FBF1E3" },
  NAO_CONTADO: { label: "Não contado", cor: "#6B7684", bg: "#EEF0F2" },
  NAO_CONSTA_NA_NOTA: { label: "Não consta na nota", cor: "#7C5CBF", bg: "#F1ECFA" },
  DIVERGENCIA_UNIDADE: { label: "Unidade divergente", cor: "#B0245A", bg: "#FBE7EF" },
};

// ---------------- Utilitários ----------------
function normalizar(texto) {
  return String(texto || "").trim().toLowerCase().replace(/\s+/g, " ");
}
function gerarChave(nome, lote) {
  return normalizar(nome) + "|" + normalizar(lote);
}
function gerarId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ---------------- Navegação ----------------
function mudarAba(aba) {
  document.querySelectorAll("main section").forEach((s) => s.classList.remove("ativa"));
  document.getElementById("secao-" + aba).classList.add("ativa");
  document.querySelectorAll("nav.bottom-nav button").forEach((b) => b.classList.remove("ativo"));
  document.getElementById("nav-" + aba).classList.add("ativo");
  if (aba === "resultado") renderResultado();
}

// ---------------- Seletores segmentados ----------------
function setUnidadeNota(valor) {
  unidadeNotaAtual = valor;
  atualizarSeg("nota-unidade-seg", valor);
}
function setUnidadeFisico(valor) {
  unidadeFisicoAtual = valor;
  atualizarSeg("fisico-unidade-seg", valor);
}
function setTipoLancamento(valor) {
  tipoLancamentoAtual = valor;
  atualizarSeg("tipo-lancamento-seg", valor);
  document.getElementById("campos-palete").style.display = valor === "palete" ? "flex" : "none";
  document.getElementById("campos-quebra").style.display = valor === "quebra" ? "block" : "none";
}
function atualizarSeg(idSeg, valor) {
  const seg = document.getElementById(idSeg);
  seg.querySelectorAll("button").forEach((b) => {
    b.classList.toggle("ativo", b.dataset.valor === valor);
  });
}

// ---------------- Nota Fiscal ----------------
function adicionarItemNota() {
  const nome = document.getElementById("nota-nome").value.trim();
  const lote = document.getElementById("nota-lote").value.trim();
  const codigo = document.getElementById("nota-codigo").value.trim();
  const quantidade = parseFloat(document.getElementById("nota-quantidade").value);

  if (!nome || !lote) return;
  if (isNaN(quantidade) || quantidade < 0) return;

  itensNota.push({ id: gerarId(), codigo, nome, lote, quantidade, unidade: unidadeNotaAtual });
  document.getElementById("nota-quantidade").value = "";
  renderListaNota();
}
function removerItemNota(id) {
  itensNota = itensNota.filter((i) => i.id !== id);
  renderListaNota();
}
function limparProdutoNota() {
  document.getElementById("nota-codigo").value = "";
  document.getElementById("nota-nome").value = "";
  document.getElementById("nota-lote").value = "";
  document.getElementById("nota-quantidade").value = "";
}
function renderListaNota() {
  const lista = document.getElementById("lista-nota");
  document.getElementById("titulo-lista-nota").textContent = `Itens da nota (${itensNota.length})`;
  atualizarBadge("nota", itensNota.length);

  if (itensNota.length === 0) {
    lista.innerHTML = `<div class="list-empty">Nenhum item adicionado ainda.</div>`;
    return;
  }
  lista.innerHTML = itensNota.map((item) => `
    <div class="list-item">
      <div style="min-width:0;">
        <p class="titulo">${escapeHtml(item.nome)}</p>
        <p class="subtitulo">Lote ${escapeHtml(item.lote)}${item.codigo ? " · Cód. " + escapeHtml(item.codigo) : ""}</p>
      </div>
      <div style="display:flex; align-items:center; gap:10px;">
        <span class="valor mono">${item.quantidade} ${item.unidade}</span>
        <button class="remover" onclick="removerItemNota('${item.id}')">✕</button>
      </div>
    </div>
  `).join("");
}

// ---------------- Contagem Física ----------------
function adicionarLancamentoFisico() {
  const nome = document.getElementById("fisico-nome").value.trim();
  const lote = document.getElementById("fisico-lote").value.trim();
  const codigo = document.getElementById("fisico-codigo").value.trim();
  if (!nome || !lote) return;

  let novo;
  if (tipoLancamentoAtual === "palete") {
    const numPaletes = parseFloat(document.getElementById("fisico-num-paletes").value);
    const qtdPorPalete = parseFloat(document.getElementById("fisico-qtd-por-palete").value);
    if (isNaN(numPaletes) || numPaletes < 0) return;
    if (isNaN(qtdPorPalete) || qtdPorPalete < 0) return;
    novo = { id: gerarId(), codigo, nome, lote, tipo: "palete", numPaletes, qtdPorPalete, unidade: unidadeFisicoAtual };
    document.getElementById("fisico-num-paletes").value = "";
    document.getElementById("fisico-qtd-por-palete").value = "";
  } else {
    const quantidade = parseFloat(document.getElementById("fisico-quantidade-quebra").value);
    if (isNaN(quantidade) || quantidade < 0) return;
    novo = { id: gerarId(), codigo, nome, lote, tipo: "quebra", quantidade, unidade: unidadeFisicoAtual };
    document.getElementById("fisico-quantidade-quebra").value = "";
  }

  lancamentosFisico.push(novo);
  renderListaFisico();
}
function removerLancamentoFisico(id) {
  lancamentosFisico = lancamentosFisico.filter((l) => l.id !== id);
  renderListaFisico();
}
function limparProdutoFisico() {
  document.getElementById("fisico-codigo").value = "";
  document.getElementById("fisico-nome").value = "";
  document.getElementById("fisico-lote").value = "";
  document.getElementById("fisico-num-paletes").value = "";
  document.getElementById("fisico-qtd-por-palete").value = "";
  document.getElementById("fisico-quantidade-quebra").value = "";
}
function renderListaFisico() {
  const lista = document.getElementById("lista-fisico");
  document.getElementById("titulo-lista-fisico").textContent = `Lançamentos físicos (${lancamentosFisico.length})`;
  atualizarBadge("contagem", lancamentosFisico.length);

  if (lancamentosFisico.length === 0) {
    lista.innerHTML = `<div class="list-empty">Nenhum lançamento adicionado ainda.</div>`;
    return;
  }
  lista.innerHTML = lancamentosFisico.map((l) => {
    const valor = l.tipo === "palete"
      ? `${l.numPaletes} × ${l.qtdPorPalete} = ${(l.numPaletes * l.qtdPorPalete)} ${l.unidade}`
      : `Quebra ${l.quantidade} ${l.unidade}`;
    return `
    <div class="list-item">
      <div style="min-width:0;">
        <p class="titulo">${escapeHtml(l.nome)}</p>
        <p class="subtitulo">Lote ${escapeHtml(l.lote)}${l.codigo ? " · Cód. " + escapeHtml(l.codigo) : ""}</p>
      </div>
      <div style="display:flex; align-items:center; gap:10px;">
        <span class="valor mono">${valor}</span>
        <button class="remover" onclick="removerLancamentoFisico('${l.id}')">✕</button>
      </div>
    </div>`;
  }).join("");
}

// ---------------- Lógica de comparação (núcleo) ----------------
function calcularResultado() {
  const mapa = new Map();

  function garantirEntrada(chave, nome, lote, codigo) {
    if (!mapa.has(chave)) {
      mapa.set(chave, {
        chave, nome, lote, codigo,
        qtdNota: 0, qtdFisico: 0,
        totalPaletesFechados: 0,
        unidadeNota: null, unidadeFisico: null,
      });
    }
    return mapa.get(chave);
  }

  itensNota.forEach((item) => {
    const chave = gerarChave(item.nome, item.lote);
    const entrada = garantirEntrada(chave, item.nome, item.lote, item.codigo);
    entrada.qtdNota += item.quantidade;
    if (!entrada.codigo) entrada.codigo = item.codigo;
    if (!entrada.unidadeNota) entrada.unidadeNota = item.unidade;
  });

  lancamentosFisico.forEach((lanc) => {
    const chave = gerarChave(lanc.nome, lanc.lote);
    const entrada = garantirEntrada(chave, lanc.nome, lanc.lote, lanc.codigo);
    if (!entrada.codigo) entrada.codigo = lanc.codigo;
    if (!entrada.unidadeFisico) entrada.unidadeFisico = lanc.unidade;

    if (lanc.tipo === "palete") {
      entrada.qtdFisico += lanc.numPaletes * lanc.qtdPorPalete;
      entrada.totalPaletesFechados += lanc.numPaletes;
    } else {
      entrada.qtdFisico += lanc.quantidade;
    }
  });

  const linhas = Array.from(mapa.values()).map((entrada) => {
    const existeNaNota = itensNota.some((i) => gerarChave(i.nome, i.lote) === entrada.chave);
    const existeNoFisico = lancamentosFisico.some((l) => gerarChave(l.nome, l.lote) === entrada.chave);

    const unidadesDivergentes = existeNaNota && existeNoFisico &&
      entrada.unidadeNota && entrada.unidadeFisico && entrada.unidadeNota !== entrada.unidadeFisico;

    let diferenca = null;
    let status = "OK";

    if (!existeNaNota) {
      status = "NAO_CONSTA_NA_NOTA";
    } else if (!existeNoFisico) {
      status = "NAO_CONTADO";
    } else if (unidadesDivergentes) {
      status = "DIVERGENCIA_UNIDADE";
    } else {
      diferenca = entrada.qtdFisico - entrada.qtdNota;
      if (diferenca > 0) status = "SOBRA";
      else if (diferenca < 0) status = "FALTA";
      else status = "OK";
    }

    return Object.assign({}, entrada, { diferenca, status });
  });

  const prioridade = { DIVERGENCIA_UNIDADE: 0, FALTA: 1, SOBRA: 2, NAO_CONTADO: 3, NAO_CONSTA_NA_NOTA: 4, OK: 5 };
  linhas.sort((a, b) => prioridade[a.status] - prioridade[b.status]);
  return linhas;
}

// ---------------- Render do Resultado ----------------
function renderResultado() {
  const linhas = calcularResultado();
  atualizarBadge("resultado", linhas.length);

  const contagemPorStatus = {};
  linhas.forEach((l) => { contagemPorStatus[l.status] = (contagemPorStatus[l.status] || 0) + 1; });

  const chipsEl = document.getElementById("chips-filtro");
  let chipsHtml = `<button class="chip ${filtroStatusAtual === "TODOS" ? "ativo" : ""}"
    style="${filtroStatusAtual === "TODOS" ? "background:#14181C;" : ""}"
    onclick="filtrarStatus('TODOS')">Todos (${linhas.length})</button>`;
  Object.keys(STATUS_CONFIG).forEach((chave) => {
    if (contagemPorStatus[chave]) {
      const cfg = STATUS_CONFIG[chave];
      const ativo = filtroStatusAtual === chave;
      chipsHtml += `<button class="chip ${ativo ? "ativo" : ""}"
        style="${ativo ? "background:" + cfg.cor + ";" : ""}"
        onclick="filtrarStatus('${chave}')">${cfg.label} (${contagemPorStatus[chave]})</button>`;
    }
  });
  chipsEl.innerHTML = chipsHtml;

  const linhasFiltradas = filtroStatusAtual === "TODOS" ? linhas : linhas.filter((l) => l.status === filtroStatusAtual);
  const listaEl = document.getElementById("lista-resultado");

  if (linhas.length === 0) {
    listaEl.innerHTML = `<div class="result-empty">Adicione itens da nota e da contagem física para ver o resultado.</div>`;
    return;
  }
  if (linhasFiltradas.length === 0) {
    listaEl.innerHTML = `<div class="result-empty">Nenhum item nesse filtro.</div>`;
    return;
  }

  listaEl.innerHTML = linhasFiltradas.map((linha) => {
    const cfg = STATUS_CONFIG[linha.status];
    const diferencaTexto = linha.diferenca === null ? "—" : (linha.diferenca > 0 ? "+" : "") + linha.diferenca;
    const corDiferenca = (linha.diferenca !== null && linha.diferenca !== 0) ? cfg.cor : "#14181C";
    const alerta = linha.status === "DIVERGENCIA_UNIDADE" ? "⚠️ " : "";
    return `
    <div class="result-card">
      <div class="stripe" style="background:${cfg.cor};"></div>
      <div class="body">
        <div class="top">
          <div>
            <p class="nome">${escapeHtml(linha.nome)}</p>
            <p class="lote">Lote ${escapeHtml(linha.lote)}${linha.codigo ? " · Cód. " + escapeHtml(linha.codigo) : ""}</p>
          </div>
          <span class="badge" style="color:${cfg.cor}; background:${cfg.bg};">${alerta}${cfg.label}</span>
        </div>
        <div class="stats mono">
          <div><p class="stat-label">Nota</p><p class="stat-valor">${linha.qtdNota}${linha.unidadeNota || ""}</p></div>
          <div><p class="stat-label">Físico</p><p class="stat-valor">${linha.qtdFisico}${linha.unidadeFisico || ""}</p></div>
          <div><p class="stat-label">Paletes</p><p class="stat-valor">${linha.totalPaletesFechados}</p></div>
          <div><p class="stat-label">Diferença</p><p class="stat-valor" style="color:${corDiferenca};">${diferencaTexto}</p></div>
        </div>
      </div>
    </div>`;
  }).join("");
}
function filtrarStatus(status) {
  filtroStatusAtual = status;
  renderResultado();
}

// ---------------- Helpers ----------------
function atualizarBadge(aba, contagem) {
  const el = document.getElementById("badge-" + aba);
  if (contagem > 0) { el.style.display = "flex"; el.textContent = contagem; }
  else { el.style.display = "none"; }
}
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------- Inicialização ----------------
renderListaNota();
renderListaFisico();